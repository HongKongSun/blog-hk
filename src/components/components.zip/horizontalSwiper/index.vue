/* 

横向滚动的swiper
 */

<template>
  <transition name="slideBottomM">
    <div class="title_wrap" v-if="list.length > 0" :class="{fixed : isFixed}">
      <ul class="swiper flex" id="swiper" ref="horswiper">
        <li
          class="swiper_inner flex flex-center flex-middle"
          v-for="(item,i) in list"
          :key="item[title]"
          :class="{'active':activeClassIndex==i,'theme':fontColor}"
          :clstag="tag?`${tag}-00${i+1}`:''"
        >
          <p class="title" :style="{color:fontColor}" @click="doChange(i)">{{item[title]}}</p>
          <div class="short_line"></div>
        </li>
      </ul>
    </div>
  </transition>
</template>

<script>
export default {
  name: "horizontalSwiper",
  components: {},
  props: {
    list: {
      type: Array,
      default: () => []
    },
    title: {
      type: String,
      default: "title"
    },
    fontColor: {
      type: String
    },
    activedIndex: {
      type: [Number, String]
    },
    // 是否需要吸顶操作
    enableFixed: {
      type: Boolean,
      default: false
    },
    // 屏幕滚动多高的时候执行吸顶操作
    flxedLength: {
      type: Number,
      default: 5.3
    },
    tag: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      isFixed: false,
      navIndex: 0
    };
  },
  watch: {},
  computed: {
    activeClassIndex() {
      if (this.activedIndex == 0) {
        return 0;
      }
      return this.activedIndex || this.navIndex;
    }
  },
  methods: {
    doChange(index) {
      // 控制横向滚动条左右滑动
      let dom = this.$refs.horswiper;
      // 屏幕宽度的一半
      let clientWidth = document.documentElement.clientWidth / 2;
      // 当前元素的距离左侧的位置
      let currentLength = dom.querySelectorAll("li")[index].offsetLeft;
      dom.scrollTo(currentLength - clientWidth, dom.offsetTop);

      this.navIndex = index;
      this.$emit("change", index);
    },

    // 滚动事件
    handleScroll() {
      // 当需要fixed的时候执行
      if (this.enableFixed) {
        let clientTop = document.querySelector("#mMain").scrollTop;
        let roorFontsize = this.getRootFontsize();

        // 固定横向滚动条
        if (clientTop > this.flxedLength * roorFontsize) {
          this.isFixed = true;
        } else {
          this.isFixed = false;
        }
      }
    }
  },
  created() {},
  mounted() {
    // 设置监听滚动事件
    setTimeout(() => {
      document
        .querySelector("#mMain")
        .addEventListener("scroll", this.handleScroll, false);
    }, 20);
  },
  destroyed() {
    document
      .querySelector("#mMain")
      .removeEventListener("scroll", this.handleScroll);
  }
};
</script>
<style lang="less" scoped>
.title_wrap {
  border-bottom: 0.01rem solid rgba(0, 0, 0, 0.1);
  overflow: hidden;
  margin-bottom: 0.37rem;
  min-width: 100%;

  &.fixed {
    position: fixed;
    top: 1.1rem;
    background: #fff;
    width: 100%;
    z-index: 20;
    box-shadow: 0px 14px 20px 0px rgba(0, 39, 123, 0.13);
  }

  .swiper {
    display: flex;
    height: 1rem;
    font-size: 0; //去除幽灵节点
    overflow: scroll;
    white-space: nowrap;

    .swiper_inner {
      flex: 1;
      padding: 0 0.2rem;
      &:first-child {
        padding-left: 0.32rem;
      }
      &:last-child {
        padding-right: 0.32rem;
      }
      flex-direction: column;
      .title {
        font-size: 0.32rem;
        height: 0.94rem;
        line-height: 0.94rem;
        text-align: center;
        color: rgba(0, 0, 0, 0.45);
      }

      .short_line {
        width: 0.4rem;
        height: 0.06rem;
        background: transparent;
      }

      &.active {
        .title {
          color: #2c68ff;
        }
        .short_line {
          background: #2c68ff;
        }
      }

      &.theme {
        color: #fff;
        &.active {
          .title {
            color: #2c68ff;
          }
          .short_line {
            background: #fff;
          }
        }
      }
    }

    &::-webkit-scrollbar {
      display: none;
    }
  }
  .line {
    border: 0.01rem solid rgba(0, 0, 0, 0.1);
    height: 0.01rem;
    position: absolute;
    width: 100%;
    bottom: 0.15rem;
  }
}
</style>