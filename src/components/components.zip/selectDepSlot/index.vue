<template>
    <div class="web">
        <el-form-item :label="selectMsg.name">
            <el-select
                    @change="comPanyAdd"
                    v-model="formExtend"
                    filterable
                    remote
                    reserve-keyword
                    :placeholder="selectMsg.holderMsg"
                    :remote-method="searchCompany"
                    :loading="loading">
                <el-option
                        v-for="item in dataList"
                        :key="item.organizationCode"
                        :label="item.organizationName"
                        :value="item.organizationCode">
                </el-option>
            </el-select>
        </el-form-item>
        <el-form-item v-if='selectData.length'  :class="{'left_c':margin}">
            <el-tag
                    v-for="item in selectList"
                    :key="item.organizationCode"
                    closable
                    :disable-transitions="false"
                    @close="handleClose(item,selectData)">
                {{item.organizationName}}
            </el-tag>
        </el-form-item>
    </div>
</template>

<script>
    export default {
        name: "selectSlot",
        props:['selectMsg','dataList','loading','margin'],
        data(){
            return{
                formExtend:'',
                selectData:[],
            }
        },
        methods:{
            comPanyAdd(){
                 let obj = {};
                obj = this.dataList.find((item)=>{
                            item.id=null
                            item.ynFlag='1'
                            return item.organizationCode === this.formExtend;
                        });
                        console.log(obj)
                if(this.checkInArr(obj.organizationCode,'organizationCode',this.selectData)) {
                    this.selectData.push(obj);
                    this.formExtend=null
                }else{
                    this.formExtend=null
                        this.$message({
                            message:'不允许重复添加',
                            type:'warning'
                        }) 
                }
                this.$emit('change',obj,this.selectData)
            },  
             //搜索
            searchCompany(query){
                this.$emit('search',query)
            },
            //删除
            handleClose(tag, list) {
                console.log(tag,list)
                if (tag.id) {
                tag.ynFlag = 0;
            } else {
                //如果是新增则直接删除
                list.splice(list.indexOf(tag), 1);
            }
      },
      //去重
            checkInArr(code,key,list){
                console.log(code,key,list)
                if(!list.length) return true
                for(var i = 0;i<list.length;i++){
                    if(list[i][key]==code){
                        return false
                    }
                }
                return true
            },
        },
        mounted() {

        },
        computed:{
            selectList(){
                return this.selectData.filter(item=>{
                    if(item.ynFlag==1) return true
                })
            }
        }
    }
</script>

<style scoped lang='less'>
.web{
    text-align: left;
    .el-tag{
        margin-right:5px;
    }
    
    .left_c{
        margin-left: 130px;
    }
}
    
</style>
